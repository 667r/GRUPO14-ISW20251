from django.db import models

# Create your models here.

class Boletin(models.Model):
    CATEGORIAS = [
        ('Cambio climático', 'Cambio climático'),
        ('Recursos hídricos', 'Recursos hídricos'),
        ('Sistemas alimentarios', 'Sistemas alimentarios'),
    ]
    
    UBICACIONES = [
        ('Región Metropolitana', 'Región Metropolitana'),
        ('Valparaíso', 'Valparaíso'),
        ('Biobío', 'Biobío'),
        ('Los Lagos', 'Los Lagos'),
        ('Araucanía', 'Araucanía'),
        ('Coquimbo', 'Coquimbo'),
        ('Antofagasta', 'Antofagasta'),
        ('O´Higgins', 'O´Higgins'),
        ('Maule', 'Maule'),
        ('Atacama', 'Atacama'),
        ('Los Ríos', 'Los Ríos'),
        ('Ñuble', 'Ñuble'),
        ('Tarapacá', 'Tarapacá'),
        ('Aysén', 'Aysén'),
        ('Magallanes', 'Magallanes'),
        ('Arica y Parinacota', 'Arica y Parinacota'),
    ]

    titulo = models.CharField(max_length=200)
    foto = models.ImageField(upload_to='boletines/')
    fecha = models.DateField()
    tipo = models.CharField(max_length=100)
    categoria = models.CharField(max_length=40, choices=CATEGORIAS)
    ubicacion = models.CharField(max_length=50, choices=UBICACIONES)

    def __str__(self):
        return self.titulo



class Temas(models.Model):

    TEMAS = [
        ('Normativas y Legislaciones','Normativas y Legislaciones'),
        ('Informes sectoriales y de mercado','Informes sectoriales y de mercado'),
        ('Patentes','Patentes'),
        ('Eventos y Seminarios','Eventos y Seminarios'),
        ('Publicaciones Cientificas','Publicaciones Cientificas'),
        ('Noticias Comerciales','Noticias Comerciales'),
        ('Blogs','Blogs'),
        ('Fuentes Sindicadas','Fuentes Sindicadas'),
        ('Estudios de Vigilancia y Prospectiva','Estudios de Vigilancia y Prospectiva'),
    ]

    REGIONES = [
        ('Región Metropolitana', 'Región Metropolitana'),
        ('Valparaíso', 'Valparaíso'),
        ('Biobío', 'Biobío'),
        ('Los Lagos', 'Los Lagos'),
        ('Araucanía', 'Araucanía'),
        ('Coquimbo', 'Coquimbo'),
        ('Antofagasta', 'Antofagasta'),
        ('O´Higgins', 'O´Higgins'),
        ('Maule', 'Maule'),
        ('Atacama', 'Atacama'),
        ('Los Ríos', 'Los Ríos'),
        ('Ñuble', 'Ñuble'),
        ('Tarapacá', 'Tarapacá'),
        ('Aysén', 'Aysén'),
        ('Magallanes', 'Magallanes'),
        ('Arica y Parinacota', 'Arica y Parinacota'),
    ]

    tema = models.CharField(max_length=100, choices = TEMAS)
    titulo = models.CharField(max_length=200)
    region = models.CharField(max_length=100, choices = REGIONES)
    informacion = models.CharField(max_length=600)

    '''def __str__(self):
        return self.titulo'''

    
