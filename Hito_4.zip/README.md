# Pasos para el correcto funcionamiento de la WebApp

    1. Asegúrese de tener Python instalado en su sistema. Se puede descargar desde python.org.

    2. Una buena práctica es crear y activar un entorno virtual para trabajar en el proyecto:

        # Crear un entorno virtual
        python -m venv myenv

        # Activar el entorno virtual
        # En Windows
        # En macOS/Linux
        source myenv/bin/activate

    3. Instalar Django utilizando pip:

        pip install django

    4. Instalar y configurar la base de datos (se usará PostgreSQL en Django):

        En Mac:
        Si estás usando macOS, puedes instalar PostgreSQL con brew:

            brew install postgresql

        Luego, inicia el servicio de PostgreSQL:

            brew services start postgresql

        En Ubuntu/Linux:

            sudo apt update
            sudo apt install postgresql postgresql-contrib

        En Windows:
        Puedes descargar PostgreSQL desde su sitio oficial: https://www.postgresql.org/download/.

        Sigue las instrucciones de instalación para tu sistema operativo.

    5. Instalar requerimientos proporcionados

        Dentro del comprimido proporcionado existe un archivo llamado 'requirements.txt', el cual, estando en el mismo directorio del archivo, debe ser instalado con:

            pip install -r requirements.txt

    6. Instalar el Adaptador de PostgreSQL para Django

        Django necesita una librería para comunicarse con PostgreSQL. Instala psycopg2, que es el adaptador más común para conectar Django con PostgreSQL.
    
            pip install psycopg2

        También puedes instalar una versión binaria que incluye dependencias precompiladas:

            psql postgres

        Crea una base de datos para tu proyecto:

            CREATE DATABASE nombre_de_tu_base_de_datos;

        Crea un usuario con contraseña:

            CREATE USER tu_usuario WITH PASSWORD 'tu_contraseña';

        Concede permisos a ese usuario sobre la base de datos:

            GRANT ALL PRIVILEGES ON DATABASE nombre_de_tu_base_de_datos TO tu_usuario;

        Sal de la consola de PostgreSQL:

            \q
        
        Si al ejecutar:

            psql postgres
        
        No sabe la contraseña de su usuario de Windows, puede seguir los siguientes pasos:

        En el buscador de Windows escribir:

            psql
        
        y abrir SQL Shell (psql), donde se le pedirá la siguiente información:

            Server [localhost]:
            Database [postgres]:
            Port [5432]:
            Username [postgres]:
            Contraseña para usuario postgres: postgres
        
        Luego, estando dentro de la shell de postgres, lo que se ve así:

            postgres=#

        se puede seguir con los pasos de la creación de la BD y usuario anteriormente proporcionados.


    7. Configurar Django para Usar PostgreSQL   

        En tu archivo de configuración de Django (Hito3/vigifia/vigifia/settings.py), busca la sección DATABASES y cámbiala para usar PostgreSQL.

            settings.py:

        DATABASES = {
            'default': {
                'ENGINE': 'django.db.backends.postgresql',
                'NAME': 'nombre_de_tu_base_de_datos',
                'USER': 'tu_usuario',
                'PASSWORD': 'tu_contraseña',
                'HOST': 'localhost',  # O la dirección de tu servidor de base de datos
                'PORT': '5432',  # El puerto predeterminado de PostgreSQL
            }
        }

    8. Importar el respaldo a la base de datos creada

        Dentro del comprimido existe un archivo llamado 'backup.sql', el cual contiene datos que ya fueron ingresados a la pagina de VIGIFIA para ilustrar mejor su funcionamiento.

        Para importar el respaldo a la base de datos creada, estando en el mismo directorio del archivo, ejecutar en la terminal:

            psql -U tu_usuario -d nombre_de_tu_base_de_datos -f backup.sql

    
    9. Aplicar Migraciones para Configurar la Base de Datos

        Django utiliza migraciones para sincronizar tu base de datos con los modelos de tu aplicación. Cada vez que haces cambios en tus modelos, debes ejecutar las migraciones para que esos cambios se reflejen en la base de datos.

        Ejecuta los siguientes comandos para aplicar las migraciones iniciales:

        python manage.py makemigrations
        python manage.py migrate    

    10. Iniciar la conexión al servidor desde Django

        En la terminal, ejecuta:

            python manage.py runserver 
        
        para levantar el servidor local y haciendo CTRL+CLICK en la URL proporcionada para poder acceder a la aplicación.
        
        System check identified no issues (0 silenced).
        October 27, 2024 - 20:14:50
        Django version 5.1.2, using settings 'vigifia.settings'
        Starting development server at http://127.0.0.1:8000/  <--------------- aquí
        Quit the server with CTRL-BREAK.
