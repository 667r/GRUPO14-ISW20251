from django.apps import AppConfig


class VigifiaAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'vigifia_app'
